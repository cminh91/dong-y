(()=>{var e={};e.id=7164,e.ids=[7164],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12909:(e,t,i)=>{"use strict";i.d(t,{BE:()=>u,Er:()=>o,HU:()=>d,Yj:()=>R,_H:()=>_,j2:()=>N});var a=i(43205),r=i.n(a),s=i(85663),c=i(44999),l=i(31183);let n=process.env.JWT_SECRET||"your-secret-key";async function o(e){return s.Ay.hash(e,12)}async function u(e,t){return s.Ay.compare(e,t)}function d(e){return r().sign(e,n,{expiresIn:"7d"})}function f(e){try{return r().verify(e,n)}catch{return null}}async function N(){try{let e=await (0,c.UL)(),t=e.get("authToken")?.value;if(!t)return null;let i=f(t);if(!i)return null;let a=await l.z.user.findUnique({where:{id:i.userId}});if(!a)return null;return{user:a}}catch{return null}}async function _(e){try{let e=await (0,c.UL)(),t=e.get("auth-token")?.value||e.get("authToken")?.value;if(!t)return null;return f(t)}catch{return null}}async function R(e,t){try{let i=e.headers.get("cookie");if(!i)return!1;let a=i.split(";").find(e=>e.trim().startsWith("authToken="))?.split("=")[1];if(!a)return!1;let r=f(a);if(!r)return!1;let s=await l.z.user.findUnique({where:{id:r.userId}});if(!s)return!1;return t.includes(s.role)}catch(e){return console.error("Error checking permission:",e),!1}}},24999:(e,t,i)=>{"use strict";i.r(t),i.d(t,{patchFetch:()=>E,routeModule:()=>f,serverHooks:()=>R,workAsyncStorage:()=>N,workUnitAsyncStorage:()=>_});var a={};i.r(a),i.d(a,{GET:()=>d});var r=i(96559),s=i(48088),c=i(37719),l=i(32190),n=i(12909),o=i(31183),u=i(45456);async function d(e){try{let t=await (0,n._H)(e);if(!t)return l.NextResponse.json({success:!1,error:"Unauthorized"},{status:401});let{searchParams:i}=new URL(e.url),a=i.get("period")||"30",r=i.get("linkId"),s=parseInt(a),c=new Date;c.setDate(c.getDate()-s);let d=await o.z.affiliateLink.findMany({where:{userId:t.userId,type:"PRODUCT"},select:{id:!0,title:!0,totalClicks:!0,totalConversions:!0}});if(0===d.length)return l.NextResponse.json({success:!0,data:{summary:{totalClicks:0,totalConversions:0,totalCommission:0,conversionRate:0,avgOrderValue:0,period:s},chartData:[],demographics:{countries:[],devices:[],hourlyDistribution:[]},linkPerformance:[]}});let f={affiliateLink:{userId:t.userId}};r&&(f.affiliateLinkId=r);let[N,_,R,E,k,p]=await Promise.all([r?o.z.$queryRaw`
          SELECT
            DATE(clicked_at) as date,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND ac.clicked_at >= ${c}
            AND ac.affiliate_link_id = ${r}
          GROUP BY DATE(clicked_at)
          ORDER BY date ASC
        `:o.z.$queryRaw`
          SELECT
            DATE(clicked_at) as date,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND ac.clicked_at >= ${c}
          GROUP BY DATE(clicked_at)
          ORDER BY date ASC
        `,r?o.z.$queryRaw`
          SELECT
            DATE(converted_at) as date,
            COUNT(*) as conversions,
            SUM(commission_amount) as commission
          FROM affiliate_conversions acv
          INNER JOIN affiliate_links al ON acv.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND acv.converted_at >= ${c}
            AND acv.affiliate_link_id = ${r}
          GROUP BY DATE(converted_at)
          ORDER BY date ASC
        `:o.z.$queryRaw`
          SELECT
            DATE(converted_at) as date,
            COUNT(*) as conversions,
            SUM(commission_amount) as commission
          FROM affiliate_conversions acv
          INNER JOIN affiliate_links al ON acv.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND acv.converted_at >= ${c}
          GROUP BY DATE(converted_at)
          ORDER BY date ASC
        `,r?o.z.$queryRaw`
          SELECT
            SUBSTRING_INDEX(ip_address, '.', 2) as country_code,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND ac.clicked_at >= ${c}
            AND ac.affiliate_link_id = ${r}
          GROUP BY country_code
          ORDER BY clicks DESC
          LIMIT 10
        `:o.z.$queryRaw`
          SELECT
            SUBSTRING_INDEX(ip_address, '.', 2) as country_code,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND ac.clicked_at >= ${c}
          GROUP BY country_code
          ORDER BY clicks DESC
          LIMIT 10
        `,r?o.z.$queryRaw`
          SELECT
            CASE
              WHEN user_agent LIKE '%Mobile%' THEN 'Mobile'
              WHEN user_agent LIKE '%Tablet%' THEN 'Tablet'
              ELSE 'Desktop'
            END as device_type,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND ac.clicked_at >= ${c}
            AND ac.affiliate_link_id = ${r}
          GROUP BY device_type
          ORDER BY clicks DESC
        `:o.z.$queryRaw`
          SELECT
            CASE
              WHEN user_agent LIKE '%Mobile%' THEN 'Mobile'
              WHEN user_agent LIKE '%Tablet%' THEN 'Tablet'
              ELSE 'Desktop'
            END as device_type,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND ac.clicked_at >= ${c}
          GROUP BY device_type
          ORDER BY clicks DESC
        `,r?o.z.$queryRaw`
          SELECT
            HOUR(clicked_at) as hour,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND ac.clicked_at >= ${c}
            AND ac.affiliate_link_id = ${r}
          GROUP BY HOUR(clicked_at)
          ORDER BY hour ASC
        `:o.z.$queryRaw`
          SELECT
            HOUR(clicked_at) as hour,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${t.userId}
            AND al.type = 'PRODUCT'
            AND ac.clicked_at >= ${c}
          GROUP BY HOUR(clicked_at)
          ORDER BY hour ASC
        `,o.z.affiliateLink.findMany({where:{userId:t.userId,type:"PRODUCT",...r?{id:r}:{}},select:{id:!0,title:!0,slug:!0,type:!0,totalClicks:!0,totalConversions:!0,totalCommission:!0,commissionRate:!0,createdAt:!0,_count:{select:{clicks:{where:{clickedAt:{gte:c}}},conversions:{where:{convertedAt:{gte:c}}}}}},orderBy:{totalClicks:"desc"}})]);N.reduce((e,t)=>e+Number(t.clicks),0),_.reduce((e,t)=>e+Number(t.conversions),0),_.reduce((e,t)=>e+Number(t.commission||0),0);let m=p.reduce((e,t)=>e+Number(t.totalClicks),0),O=p.reduce((e,t)=>e+Number(t.totalConversions),0),D=p.reduce((e,t)=>e+Number(t.totalCommission),0),C=m>0?O/m*100:0,v=O>0?D/O:0,y=[],T=new Map;N.forEach(e=>{let t=e.date.toISOString().split("T")[0];T.set(t,{date:t,clicks:Number(e.clicks),conversions:0,commission:0})}),_.forEach(e=>{let t=e.date.toISOString().split("T")[0],i=T.get(t)||{date:t,clicks:0,conversions:0,commission:0};i.conversions=Number(e.conversions),i.commission=Number(e.commission||0),T.set(t,i)}),y.push(...Array.from(T.values()).sort((e,t)=>e.date.localeCompare(t.date)));let I={success:!0,data:{summary:{totalClicks:Number(m),totalConversions:Number(O),totalCommission:Number(D),conversionRate:Number(C.toFixed(2)),avgOrderValue:Number(v.toFixed(2)),period:s},chartData:(0,u.H)(y),demographics:{countries:(0,u.H)(R),devices:(0,u.H)(E),hourlyDistribution:(0,u.H)(k)},linkPerformance:p.map(e=>({...e,totalClicks:Number(e.totalClicks),totalConversions:Number(e.totalConversions),totalCommission:Number(e.totalCommission),commissionRate:Number(e.commissionRate),periodClicks:Number(e._count.clicks),periodConversions:Number(e._count.conversions),periodConversionRate:e._count.clicks>0?Number((e._count.conversions/e._count.clicks*100).toFixed(2)):0}))}};return l.NextResponse.json(I)}catch(e){return l.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}let f=new r.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/affiliate/performance/route",pathname:"/api/affiliate/performance",filename:"route",bundlePath:"app/api/affiliate/performance/route"},resolvedPagePath:"D:\\dong-y\\src\\app\\api\\affiliate\\performance\\route.ts",nextConfigOutput:"standalone",userland:a}),{workAsyncStorage:N,workUnitAsyncStorage:_,serverHooks:R}=f;function E(){return(0,c.patchFetch)({workAsyncStorage:N,workUnitAsyncStorage:_})}},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},31183:(e,t,i)=>{"use strict";i.d(t,{z:()=>r});var a=i(96330);let r=globalThis.prisma??new a.PrismaClient({log:["error"],datasources:{db:{url:process.env.DATABASE_URL}}})},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},45456:(e,t,i)=>{"use strict";i.d(t,{H:()=>function e(t){if("bigint"==typeof t)return Number(t);if(t instanceof Date)return t.toISOString();if(Array.isArray(t))return t.map(e);if(null!==t&&"object"==typeof t){let i={};for(let a in t)t.hasOwnProperty(a)&&(i[a]=e(t[a]));return i}return t}})},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},96330:e=>{"use strict";e.exports=require("@prisma/client")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),a=t.X(0,[4447,580,3205,4999,5663],()=>i(24999));module.exports=a})();