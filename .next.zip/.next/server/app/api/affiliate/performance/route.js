(()=>{var e={};e.id=7164,e.ids=[7164],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12909:(e,i,a)=>{"use strict";a.d(i,{BE:()=>u,Er:()=>o,HU:()=>d,_H:()=>E,j2:()=>_});var t=a(43205),r=a.n(t),s=a(85663),c=a(44999),l=a(31183);let n=process.env.JWT_SECRET||"your-secret-key";async function o(e){return s.Ay.hash(e,12)}async function u(e,i){return s.Ay.compare(e,i)}function d(e){return r().sign(e,n,{expiresIn:"7d"})}function f(e){try{return r().verify(e,n)}catch{return null}}async function _(){try{let e=await (0,c.UL)(),i=e.get("authToken")?.value;if(!i)return null;let a=f(i);if(!a)return null;let t=await l.z.user.findUnique({where:{id:a.userId}});if(!t)return null;return{user:t}}catch{return null}}async function E(e){try{let e=await (0,c.UL)(),i=e.get("auth-token")?.value||e.get("authToken")?.value;if(!i)return null;return f(i)}catch{return null}}},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},31183:(e,i,a)=>{"use strict";a.d(i,{z:()=>r});var t=a(96330);let r=globalThis.prisma??new t.PrismaClient},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},45456:(e,i,a)=>{"use strict";a.d(i,{H:()=>function e(i){if("bigint"==typeof i)return Number(i);if(Array.isArray(i))return i.map(e);if(null!==i&&"object"==typeof i){let a={};for(let t in i)i.hasOwnProperty(t)&&(a[t]=e(i[t]));return a}return i}})},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},92262:(e,i,a)=>{"use strict";a.r(i),a.d(i,{patchFetch:()=>k,routeModule:()=>f,serverHooks:()=>N,workAsyncStorage:()=>_,workUnitAsyncStorage:()=>E});var t={};a.r(t),a.d(t,{GET:()=>d});var r=a(96559),s=a(48088),c=a(37719),l=a(32190),n=a(12909),o=a(31183),u=a(45456);async function d(e){try{let i=await (0,n._H)(e);if(!i)return l.NextResponse.json({success:!1,error:"Unauthorized"},{status:401});let{searchParams:a}=new URL(e.url),t=a.get("period")||"30",r=a.get("linkId"),s=parseInt(t),c=new Date;c.setDate(c.getDate()-s);let d={affiliateLink:{userId:i.userId}};r&&(d.affiliateLinkId=r);let[f,_,E,N,k,R]=await Promise.all([r?o.z.$queryRaw`
          SELECT
            DATE(clicked_at) as date,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND ac.clicked_at >= ${c}
            AND ac.affiliate_link_id = ${r}
          GROUP BY DATE(clicked_at)
          ORDER BY date ASC
        `:o.z.$queryRaw`
          SELECT
            DATE(clicked_at) as date,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND ac.clicked_at >= ${c}
          GROUP BY DATE(clicked_at)
          ORDER BY date ASC
        `,r?o.z.$queryRaw`
          SELECT
            DATE(converted_at) as date,
            COUNT(*) as conversions,
            SUM(commission_amount) as commission
          FROM affiliate_conversions acv
          INNER JOIN affiliate_links al ON acv.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND acv.converted_at >= ${c}
            AND acv.affiliate_link_id = ${r}
          GROUP BY DATE(converted_at)
          ORDER BY date ASC
        `:o.z.$queryRaw`
          SELECT
            DATE(converted_at) as date,
            COUNT(*) as conversions,
            SUM(commission_amount) as commission
          FROM affiliate_conversions acv
          INNER JOIN affiliate_links al ON acv.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND acv.converted_at >= ${c}
          GROUP BY DATE(converted_at)
          ORDER BY date ASC
        `,r?o.z.$queryRaw`
          SELECT
            SUBSTRING_INDEX(ip_address, '.', 2) as country_code,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND ac.clicked_at >= ${c}
            AND ac.affiliate_link_id = ${r}
          GROUP BY country_code
          ORDER BY clicks DESC
          LIMIT 10
        `:o.z.$queryRaw`
          SELECT
            SUBSTRING_INDEX(ip_address, '.', 2) as country_code,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND ac.clicked_at >= ${c}
          GROUP BY country_code
          ORDER BY clicks DESC
          LIMIT 10
        `,r?o.z.$queryRaw`
          SELECT
            CASE
              WHEN user_agent LIKE '%Mobile%' THEN 'Mobile'
              WHEN user_agent LIKE '%Tablet%' THEN 'Tablet'
              ELSE 'Desktop'
            END as device_type,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND ac.clicked_at >= ${c}
            AND ac.affiliate_link_id = ${r}
          GROUP BY device_type
          ORDER BY clicks DESC
        `:o.z.$queryRaw`
          SELECT
            CASE
              WHEN user_agent LIKE '%Mobile%' THEN 'Mobile'
              WHEN user_agent LIKE '%Tablet%' THEN 'Tablet'
              ELSE 'Desktop'
            END as device_type,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND ac.clicked_at >= ${c}
          GROUP BY device_type
          ORDER BY clicks DESC
        `,r?o.z.$queryRaw`
          SELECT
            HOUR(clicked_at) as hour,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND ac.clicked_at >= ${c}
            AND ac.affiliate_link_id = ${r}
          GROUP BY HOUR(clicked_at)
          ORDER BY hour ASC
        `:o.z.$queryRaw`
          SELECT
            HOUR(clicked_at) as hour,
            COUNT(*) as clicks
          FROM affiliate_clicks ac
          INNER JOIN affiliate_links al ON ac.affiliate_link_id = al.id
          WHERE al.user_id = ${i.userId}
            AND ac.clicked_at >= ${c}
          GROUP BY HOUR(clicked_at)
          ORDER BY hour ASC
        `,o.z.affiliateLink.findMany({where:{userId:i.userId,...r?{id:r}:{}},select:{id:!0,title:!0,slug:!0,type:!0,totalClicks:!0,totalConversions:!0,totalCommission:!0,commissionRate:!0,createdAt:!0,_count:{select:{clicks:{where:{clickedAt:{gte:c}}},conversions:{where:{convertedAt:{gte:c}}}}}},orderBy:{totalClicks:"desc"}})]),p=f.reduce((e,i)=>e+Number(i.clicks),0),m=_.reduce((e,i)=>e+Number(i.conversions),0),O=_.reduce((e,i)=>e+Number(i.commission||0),0),v=[],I=new Map;return f.forEach(e=>{let i=e.date.toISOString().split("T")[0];I.set(i,{date:i,clicks:Number(e.clicks),conversions:0,commission:0})}),_.forEach(e=>{let i=e.date.toISOString().split("T")[0],a=I.get(i)||{date:i,clicks:0,conversions:0,commission:0};a.conversions=Number(e.conversions),a.commission=Number(e.commission||0),I.set(i,a)}),v.push(...Array.from(I.values()).sort((e,i)=>e.date.localeCompare(i.date))),l.NextResponse.json({success:!0,data:{summary:{totalClicks:Number(p),totalConversions:Number(m),totalCommission:Number(O),conversionRate:Number((p>0?m/p*100:0).toFixed(2)),avgOrderValue:Number((m>0?O/m:0).toFixed(2)),period:s},chartData:(0,u.H)(v),demographics:{countries:(0,u.H)(E),devices:(0,u.H)(N),hourlyDistribution:(0,u.H)(k)},linkPerformance:R.map(e=>({...e,totalClicks:Number(e.totalClicks),totalConversions:Number(e.totalConversions),totalCommission:Number(e.totalCommission),commissionRate:Number(e.commissionRate),periodClicks:Number(e._count.clicks),periodConversions:Number(e._count.conversions),periodConversionRate:e._count.clicks>0?Number((e._count.conversions/e._count.clicks*100).toFixed(2)):0}))}})}catch(e){return console.error("Error fetching performance data:",e),l.NextResponse.json({success:!1,error:"Internal server error"},{status:500})}}let f=new r.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/affiliate/performance/route",pathname:"/api/affiliate/performance",filename:"route",bundlePath:"app/api/affiliate/performance/route"},resolvedPagePath:"D:\\dongypharmacy\\src\\app\\api\\affiliate\\performance\\route.ts",nextConfigOutput:"",userland:t}),{workAsyncStorage:_,workUnitAsyncStorage:E,serverHooks:N}=f;function k(){return(0,c.patchFetch)({workAsyncStorage:_,workUnitAsyncStorage:E})}},96330:e=>{"use strict";e.exports=require("@prisma/client")},96487:()=>{}};var i=require("../../../../webpack-runtime.js");i.C(e);var a=e=>i(i.s=e),t=i.X(0,[4447,580,3205,4999,5663],()=>a(92262));module.exports=t})();