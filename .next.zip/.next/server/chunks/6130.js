"use strict";exports.id=6130,exports.ids=[6130],exports.modules={86130:(e,t,i)=>{i.d(t,{A:()=>n});var l=i(60687),a=i(43210),r=i(54621),s=i(37590);let n=({value:e,onEditorChange:t,height:i=600,placeholder:n="Nhập nội dung chi tiết...",folder:o="posts",showSEOTips:c=!0})=>{let[h,d]=(0,a.useState)(c),p=async e=>{let t=new FormData;t.append("files",e),t.append("folder",o);let i=await fetch("/api/upload",{method:"POST",body:t}),l=await i.json();if(l.success&&l.data?.files?.length>0)return l.data.files[0].url;throw Error(l.error||"Upload failed")};return(0,l.jsxs)("div",{className:"w-full",children:[c&&h&&(0,l.jsx)("div",{className:"mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg",children:(0,l.jsxs)("div",{className:"flex justify-between items-start",children:[(0,l.jsxs)("div",{children:[(0,l.jsx)("h4",{className:"text-sm font-semibold text-blue-800 mb-2",children:"\uD83D\uDCA1 Tips viết b\xe0i chuẩn SEO:"}),(0,l.jsxs)("ul",{className:"text-xs text-blue-700 space-y-1",children:[(0,l.jsx)("li",{children:"• Sử dụng H1 cho ti\xeau đề ch\xednh (chỉ 1 lần)"}),(0,l.jsx)("li",{children:"• Sử dụng H2, H3 để ph\xe2n chia nội dung r\xf5 r\xe0ng"}),(0,l.jsx)("li",{children:"• Th\xeam alt text cho tất cả h\xecnh ảnh"}),(0,l.jsx)("li",{children:"• Upload ảnh bằng Insert → Image (kh\xf4ng paste trực tiếp)"}),(0,l.jsx)("li",{children:"• Sử dụng danh s\xe1ch để tổ chức th\xf4ng tin"}),(0,l.jsx)("li",{children:"• Nội dung n\xean từ 300-2000 từ"})]})]}),(0,l.jsx)("button",{type:"button",onClick:()=>d(!1),className:"text-blue-600 hover:text-blue-800 text-sm",children:"✕"})]})}),(0,l.jsx)(r.K,{apiKey:"1exbwbvl8zurva67fbupgrx9ctjgz7hul3zv01rfgmrj3gb3",value:e||"",onEditorChange:t,init:{height:i,menubar:"file edit view insert format tools table help",plugins:["advlist","autolink","lists","link","image","charmap","preview","anchor","searchreplace","visualblocks","code","fullscreen","insertdatetime","media","table","help","wordcount","emoticons","codesample","hr","pagebreak","nonbreaking","template","textpattern"],toolbar1:"undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | forecolor backcolor | alignleft aligncenter alignright alignjustify",toolbar2:"bullist numlist | outdent indent | link unlink anchor | image media table | hr pagebreak | searchreplace | visualblocks code fullscreen",toolbar3:"insertdatetime | charmap emoticons | codesample | template | preview help",content_style:`
            body { 
              font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
              font-size: 14px; 
              line-height: 1.6;
              color: #374151;
            }
            img { 
              max-width: 100%; 
              height: auto; 
              border-radius: 8px;
              box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            }
            p { margin: 0 0 1rem 0; }
          `,placeholder:n,branding:!1,promotion:!1,skin:"oxide",content_css:"default",setup:e=>{e.on("init",()=>{let t=e.getContainer();t.style.transition="border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out",t.style.borderRadius="0.5rem",t.style.border="1px solid #d1d5db"}),e.on("focus",()=>{let t=e.getContainer();t.style.borderColor="#10b981",t.style.boxShadow="0 0 0 2px rgba(16, 185, 129, 0.2)"}),e.on("blur",()=>{let t=e.getContainer();t.style.borderColor="#d1d5db",t.style.boxShadow="none"}),e.on("PastePostProcess",e=>{let t=e.node.querySelectorAll("img");t.length>0&&s.Ay.success(`Đ\xe3 paste ${t.length} ảnh th\xe0nh c\xf4ng`)})},paste_data_images:!0,paste_as_text:!1,paste_word_valid_elements:"*[*]",paste_webkit_styles:"all",paste_retain_style_properties:"all",paste_merge_formats:!0,paste_auto_cleanup_on_paste:!0,paste_remove_styles_if_webkit:!1,paste_strip_class_attributes:"none",paste_enable_default_filters:!1,paste_preprocess:(e,t)=>{let i=t.content;t.content=i.replace(/mso-[^;]+;?/gi,"")},paste_postprocess:(e,t)=>{t.node.querySelectorAll("img").forEach(e=>{e.src&&(e.style.maxWidth="100%",e.style.height="auto",e.style.borderRadius="8px",e.style.boxShadow="0 1px 3px rgba(0, 0, 0, 0.1)",e.className=(e.className||"")+" responsive-image")})},link_default_target:"_blank",link_assume_external_targets:!0,image_advtab:!0,image_caption:!0,image_description:!0,image_dimensions:!0,image_title:!0,image_class_list:[{title:"Responsive",value:"img-responsive"},{title:"Rounded",value:"img-rounded"},{title:"Circle",value:"img-circle"},{title:"Thumbnail",value:"img-thumbnail"}],file_picker_types:"image",file_picker_callback:(e,t,i)=>{if("image"===i.filetype){let t=document.createElement("input");t.setAttribute("type","file"),t.setAttribute("accept","image/*"),t.onchange=async t=>{let i=t.target,l=i.files?.[0];if(l)try{let t=await p(l);e(t,{alt:l.name.replace(/\.[^/.]+$/,""),title:l.name.replace(/\.[^/.]+$/,"")}),s.Ay.success("Tải ảnh l\xean th\xe0nh c\xf4ng!")}catch(e){console.error("File picker upload error:",e),s.Ay.error("Lỗi khi tải ảnh l\xean")}},t.click()}},automatic_uploads:!1,images_upload_handler:void 0,resize:!0,statusbar:!0,elementpath:!1,contextmenu:"link image table",paste_block_drop:!1,browser_spellcheck:!0,convert_urls:!1,relative_urls:!1,templates:[{title:"B\xe0i viết cơ bản",description:"Template cho b\xe0i viết th\xf4ng thường",content:`
                <h1>Ti\xeau đề ch\xednh</h1>
                <p>Mở đầu b\xe0i viết...</p>

                <h2>Phần 1</h2>
                <p>Nội dung phần 1...</p>

                <h2>Phần 2</h2>
                <p>Nội dung phần 2...</p>

                <h2>Kết luận</h2>
                <p>T\xf3m tắt v\xe0 kết luận...</p>
              `},{title:"B\xe0i review sản phẩm",description:"Template cho b\xe0i review",content:`
                <h1>Review [T\xean sản phẩm]</h1>

                <h2>Th\xf4ng tin sản phẩm</h2>
                <ul>
                  <li><strong>T\xean:</strong> </li>
                  <li><strong>Gi\xe1:</strong> </li>
                  <li><strong>Thương hiệu:</strong> </li>
                </ul>

                <h2>Ưu điểm</h2>
                <ul>
                  <li></li>
                </ul>

                <h2>Nhược điểm</h2>
                <ul>
                  <li></li>
                </ul>

                <h2>Đ\xe1nh gi\xe1 tổng thể</h2>
                <p>Rating: ⭐⭐⭐⭐⭐</p>
                <p>Kết luận...</p>
              `}],textpattern_patterns:[{start:"*",end:"*",format:"italic"},{start:"**",end:"**",format:"bold"},{start:"#",format:"h1"},{start:"##",format:"h2"},{start:"###",format:"h3"},{start:"1. ",cmd:"InsertOrderedList"},{start:"* ",cmd:"InsertUnorderedList"},{start:"- ",cmd:"InsertUnorderedList"}],wordcount:{showWords:!0,showCharacters:!0,showCharactersWithoutSpaces:!1,countSpacesAsSeparateWords:!1},style_formats:[{title:"Headings",items:[{title:"Heading 1",format:"h1"},{title:"Heading 2",format:"h2"},{title:"Heading 3",format:"h3"},{title:"Heading 4",format:"h4"},{title:"Heading 5",format:"h5"},{title:"Heading 6",format:"h6"}]},{title:"Inline",items:[{title:"Bold",format:"bold"},{title:"Italic",format:"italic"},{title:"Underline",format:"underline"},{title:"Strikethrough",format:"strikethrough"},{title:"Superscript",format:"superscript"},{title:"Subscript",format:"subscript"},{title:"Code",format:"code"}]},{title:"Blocks",items:[{title:"Paragraph",format:"p"},{title:"Blockquote",format:"blockquote"},{title:"Div",format:"div"},{title:"Pre",format:"pre"}]},{title:"Alignment",items:[{title:"Left",format:"alignleft"},{title:"Center",format:"aligncenter"},{title:"Right",format:"alignright"},{title:"Justify",format:"alignjustify"}]}]}})]})}}};